# Jiasmin Video Studio

Android video editor (Kotlin, Jetpack Compose, AndroidX Media3 Transformer). Original app and branding.
Owner: MD Sobus Miya. minSdk 29 (Android 10+).

## Build the APK with GitHub (no Android Studio needed)
1. Create a new repository on github.com.
2. Upload ALL files from this folder (keep the `.github/workflows/android.yml` path and the `app` folder).
3. Open the **Actions** tab, choose **Android CI**, press **Run workflow** (it also runs on every push).
4. When the run is green, open it and download **JiasminVideoStudio-debug-apk** under *Artifacts*.
5. Unzip it, copy `app-debug.apk` to your phone, install (allow "install unknown apps").
If the run fails, download **build-logs** and send it to Claude.

## Build with Android Studio
Open this folder, wait for Gradle sync, press Run. APK path: `app/build/outputs/apk/debug/app-debug.apk`.

## Working features (written, NOT yet compiled or tested by the author)
Home, saved projects (save/open/delete), import video and photo, preview (with filters, effects and crop),
trim, split, duplicate, delete, reorder, replace, merge, speed, rotate, flip, free crop, aspect ratio,
text (Default/Serif/Mono, Bangla via system font) and emoji stickers, image overlays (logo or photo on top),
filters and brightness, effects (Zoom in, Pulse, Shake, Invert, Sepia), transitions at clip start (Fade, Slide, Zoom),
freeze frame, capture frame to Pictures, clip volume and mute, voice effects (Chipmunk, Deep),
music import, voice-over recording, export settings with encoder check, size/memory/storage estimates,
progress, cancel, save to Movies/JiasminVideoStudio, play, share, About Me with YouTube, Facebook, TikTok, Telegram.

## Also added in this version
Opacity (blends toward black), Fit/Fill canvas mode, Auto enhance filter (contrast and color boost, not AI),
text-to-speech using the phone's voice (Bangla if the phone has a Bangla voice), custom font file import, templates.

## Not included (and why)
Cross-dissolve and video picture-in-picture (no stable compositor API in Media3 1.4.1), reverse (not supported by Transformer),
mask and background blur (need custom GPU shaders), stabilizer, AI Cut, cutout, voice enhance (need ML models),
server-side rendering (needs a server you run).

## Known risks
Transitions and effects use time-based Media3 effects. Their timing inside a merged video has not been verified on a device.
Mixing photos and videos in one export may fail on some phones; if it does, export them separately.

## 20K note
20K (20480 x 11520) and custom sizes are enabled only if a hardware/software encoder on the phone reports that size.
Otherwise the app shows the highest supported size. A smaller file is never labelled 20K.
