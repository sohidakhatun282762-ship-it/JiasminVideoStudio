package com.jiasmin.videostudio

import org.junit.Assert.assertEquals
import org.junit.Test

class DimsTest {
    @Test fun landscape1080() = assertEquals(Pair(1920, 1080), Dims.compute(16 / 9.0, 1080))
    @Test fun portrait1080() = assertEquals(Pair(1080, 1920), Dims.compute(9 / 16.0, 1080))
    @Test fun square720() = assertEquals(Pair(720, 720), Dims.compute(1.0, 720))
    @Test fun twentyK() = assertEquals(Pair(20480, 11520), Dims.compute(16 / 9.0, 11520))
}
