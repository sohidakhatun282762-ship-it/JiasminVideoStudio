package com.jiasmin.videostudio

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Clip(
    val uri: String, val isImage: Boolean, val durationMs: Long, val width: Int, val height: Int,
    val startMs: Long = 0, val endMs: Long = durationMs, val speed: Float = 1f, val rotate: Int = 0,
    val flip: Boolean = false, val volume: Float = 1f, val filter: String = "None", val brightness: Float = 0f,
    val effect: String = "None", val transition: String = "None", val voice: String = "None",
    val cropL: Float = 0f, val cropR: Float = 0f, val cropT: Float = 0f, val cropB: Float = 0f,
    val opacity: Float = 1f
)
data class TextItem(val text: String, val y: Float, val sizePx: Int, val color: Int, val font: String = "Default")
data class ImageOverlay(val uri: String, val x: Float, val y: Float, val scale: Float)
data class AudioTrack(val uri: String, val label: String, val volume: Float = 1f)
data class Project(
    val name: String, val clips: List<Clip> = emptyList(), val texts: List<TextItem> = emptyList(),
    val audio: List<AudioTrack> = emptyList(), val aspect: String = "Original",
    val overlays: List<ImageOverlay> = emptyList(), val fill: Boolean = false
)

object Dims {
    fun ratio(p: Project): Double = when (p.aspect) {
        "1:1" -> 1.0
        "4:5" -> 0.8
        "9:16" -> 9 / 16.0
        "16:9" -> 16 / 9.0
        else -> {
            val c = p.clips.firstOrNull()
            if (c == null || c.width <= 0 || c.height <= 0) 16 / 9.0
            else if (c.rotate % 180 != 0) c.height.toDouble() / c.width else c.width.toDouble() / c.height
        }
    }

    fun compute(ratio: Double, shortSide: Int): Pair<Int, Int> {
        val w: Int
        val h: Int
        if (ratio >= 1) { h = shortSide; w = Math.round(shortSide * ratio).toInt() }
        else { w = shortSide; h = Math.round(shortSide / ratio).toInt() }
        return Pair(w - w % 2, h - h % 2)
    }

    fun totalMs(p: Project): Long = p.clips.sumOf {
        if (it.isImage) it.endMs - it.startMs else ((it.endMs - it.startMs) / it.speed).toLong()
    }
}

object Media {
    fun probe(ctx: Context, uri: Uri): Clip? {
        try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        val mime = ctx.contentResolver.getType(uri) ?: ""
        if (mime.startsWith("image/")) {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            try { ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } } catch (_: Exception) { return null }
            return Clip(uri.toString(), true, 3000, o.outWidth, o.outHeight)
        }
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: return null
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot % 180 != 0) { val t = w; w = h; h = t }
            if (w <= 0 || h <= 0) null else Clip(uri.toString(), false, dur, w, h)
        } catch (_: Exception) { null } finally { r.release() }
    }

    fun dims(ctx: Context, uri: Uri?): String {
        if (uri == null) return "unknown"
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot % 180 != 0) "${h}x$w" else "${w}x$h"
        } catch (_: Exception) { "unknown" } finally { r.release() }
    }

    fun frameAt(ctx: Context, uri: String, ms: Long): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, Uri.parse(uri))
            r.getFrameAtTime(ms * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
        } catch (_: Exception) { null } finally { r.release() }
    }

    fun saveImage(ctx: Context, bmp: Bitmap): Boolean {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "Jiasmin_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/JiasminVideoStudio")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return false
        return try {
            ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            true
        } catch (_: Exception) { ctx.contentResolver.delete(uri, null, null); false }
    }

    fun saveToGallery(ctx: Context, file: File): Uri? {
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "Jiasmin_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/JiasminVideoStudio")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return null
        return try {
            ctx.contentResolver.openOutputStream(uri)?.use { o -> file.inputStream().use { it.copyTo(o) } }
            v.clear(); v.put(MediaStore.Video.Media.IS_PENDING, 0)
            ctx.contentResolver.update(uri, v, null, null)
            file.delete()
            uri
        } catch (_: Exception) { ctx.contentResolver.delete(uri, null, null); null }
    }
}

object Store {
    private fun dir(ctx: Context) = File(ctx.filesDir, "projects").also { it.mkdirs() }
    private fun safe(n: String) = n.filter { it.isLetterOrDigit() || it == '-' || it == '_' || it == ' ' }.ifBlank { "project" }

    fun save(ctx: Context, p: Project) {
        val j = JSONObject()
        j.put("name", p.name); j.put("aspect", p.aspect)
        j.put("clips", JSONArray().also { a -> p.clips.forEach { c -> a.put(JSONObject().apply {
            put("uri", c.uri); put("img", c.isImage); put("dur", c.durationMs); put("w", c.width); put("h", c.height)
            put("s", c.startMs); put("e", c.endMs); put("sp", c.speed.toDouble()); put("rot", c.rotate); put("flip", c.flip)
            put("vol", c.volume.toDouble()); put("fil", c.filter); put("br", c.brightness.toDouble())
            put("fx", c.effect); put("tr", c.transition); put("vf", c.voice)
            put("cl", c.cropL.toDouble()); put("cr", c.cropR.toDouble()); put("ct", c.cropT.toDouble()); put("cb", c.cropB.toDouble()); put("op", c.opacity.toDouble()) }) } })
        j.put("texts", JSONArray().also { a -> p.texts.forEach { t -> a.put(JSONObject().apply {
            put("t", t.text); put("y", t.y.toDouble()); put("sz", t.sizePx); put("c", t.color); put("f", t.font) }) } })
        j.put("audio", JSONArray().also { a -> p.audio.forEach { t -> a.put(JSONObject().apply {
            put("u", t.uri); put("l", t.label); put("v", t.volume.toDouble()) }) } })
        j.put("overlays", JSONArray().also { a -> p.overlays.forEach { o -> a.put(JSONObject().apply {
            put("u", o.uri); put("x", o.x.toDouble()); put("y", o.y.toDouble()); put("s", o.scale.toDouble()) }) } })
        j.put("fill", p.fill)
        val tmp = File(dir(ctx), safe(p.name) + ".tmp")
        tmp.writeText(j.toString())
        tmp.renameTo(File(dir(ctx), safe(p.name) + ".json"))
    }

    fun list(ctx: Context): List<String> = dir(ctx).listFiles()?.filter { it.extension == "json" }
        ?.sortedByDescending { it.lastModified() }?.map { it.nameWithoutExtension } ?: emptyList()

    fun delete(ctx: Context, name: String) { File(dir(ctx), safe(name) + ".json").delete() }

    fun load(ctx: Context, name: String): Project? = try {
        val j = JSONObject(File(dir(ctx), safe(name) + ".json").readText())
        val ca = j.getJSONArray("clips"); val ta = j.getJSONArray("texts"); val aa = j.getJSONArray("audio")
        Project(
            j.getString("name"),
            (0 until ca.length()).map { val c = ca.getJSONObject(it)
                Clip(c.getString("uri"), c.getBoolean("img"), c.getLong("dur"), c.getInt("w"), c.getInt("h"), c.getLong("s"), c.getLong("e"),
                    c.getDouble("sp").toFloat(), c.getInt("rot"), c.getBoolean("flip"), c.getDouble("vol").toFloat(), c.getString("fil"), c.getDouble("br").toFloat(),
                    effect = c.optString("fx", "None"), transition = c.optString("tr", "None"), voice = c.optString("vf", "None"),
                    cropL = c.optDouble("cl", 0.0).toFloat(), cropR = c.optDouble("cr", 0.0).toFloat(),
                    cropT = c.optDouble("ct", 0.0).toFloat(), cropB = c.optDouble("cb", 0.0).toFloat(),
                    opacity = c.optDouble("op", 1.0).toFloat()) },
            (0 until ta.length()).map { val t = ta.getJSONObject(it); TextItem(t.getString("t"), t.getDouble("y").toFloat(), t.getInt("sz"), t.getInt("c"), t.optString("f", "Default")) },
            (0 until aa.length()).map { val t = aa.getJSONObject(it); AudioTrack(t.getString("u"), t.getString("l"), t.getDouble("v").toFloat()) },
            j.getString("aspect"),
            (0 until (j.optJSONArray("overlays")?.length() ?: 0)).map {
                val o = j.getJSONArray("overlays").getJSONObject(it)
                ImageOverlay(o.getString("u"), o.getDouble("x").toFloat(), o.getDouble("y").toFloat(), o.getDouble("s").toFloat())
            },
            j.optBoolean("fill", false)
        )
    } catch (_: Exception) { null }
}
