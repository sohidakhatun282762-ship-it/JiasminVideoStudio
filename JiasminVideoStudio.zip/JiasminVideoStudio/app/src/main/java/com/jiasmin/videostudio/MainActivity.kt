@file:OptIn(androidx.media3.common.util.UnstableApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.jiasmin.videostudio

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.StatFs
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.util.Locale

val Indigo = Color(0xFF15123A); val Panel = Color(0xFF201C52); val Coral = Color(0xFFFF6B4A)
val Amber = Color(0xFFFFC247); val Teal = Color(0xFF35D6C4); val Ink = Color(0xFFF4F1FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Coral, onPrimary = Color(0xFF2A1200), secondary = Teal,
                tertiary = Amber, background = Indigo, surface = Panel, onBackground = Ink, onSurface = Ink)) { App() }
        }
    }
}

val EFFECTS = listOf("None", "Zoom in", "Pulse", "Shake", "Invert", "Sepia")
val TRANSITIONS = listOf("None", "Fade", "Slide", "Zoom")
val VOICES = listOf("None", "Chipmunk", "Deep")
val FONTS = listOf("Default", "Serif", "Mono")

fun fmt(ms: Long) = String.format(Locale.US, "%.1fs", ms / 1000.0)
fun openUrl(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
}

@Composable fun App() {
    val ctx = LocalContext.current
    val st = remember { AppState(ctx.applicationContext) }
    DisposableEffect(Unit) { onDispose { st.releaseRecorder() } }
    BackHandler(st.screen != "home") { if (st.screen == "export") st.screen = "edit" else { st.save(); st.screen = "home" } }
    Surface(Modifier.fillMaxSize().systemBarsPadding(), color = MaterialTheme.colorScheme.background) {
        when (st.screen) { "home" -> Home(st); "edit" -> Editor(st); else -> ExportScreen(st) }
    }
}

@Composable fun Home(st: AppState) {
    val ctx = LocalContext.current
    var saved by remember { mutableStateOf(Store.list(ctx)) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Jiasmin Video Studio", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Coral)
        Text("Import, edit and export videos on your phone.")
        Button(onClick = { st.project = Project("Project ${System.currentTimeMillis() % 100000}"); st.sel = 0; st.message = ""; st.screen = "edit" },
            Modifier.fillMaxWidth().height(56.dp)) { Text("New project") }
        if (saved.isNotEmpty()) Text("Saved projects", fontWeight = FontWeight.SemiBold)
        saved.forEach { n ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(n, Modifier.weight(1f).padding(start = 8.dp))
                TextButton(onClick = {
                    val p = Store.load(ctx, n)
                    if (p != null) { st.project = p; st.sel = 0; st.message = ""; st.screen = "edit" } else st.message = "Could not open $n."
                }) { Text("Open") }
                TextButton(onClick = { Store.delete(ctx, n); saved = Store.list(ctx) }) { Text("Delete") }
            }
        }
        if (st.message.isNotEmpty()) Text(st.message, color = Amber)
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Panel).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.profile), "MD Sobus Miya", Modifier.size(120.dp).clip(CircleShape), contentScale = ContentScale.Crop)
            Spacer(Modifier.height(8.dp))
            Text("MD Sobus Miya", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Developer, Content Creator, AI Enthusiast")
            Spacer(Modifier.height(12.dp))
            val links = listOf(
                Triple("YouTube", "https://youtube.com/channel/UC2RtSEIotYvkGS2uICvE7Cw?si=kRr8zqwW47HvzOWE", Color(0xFFE5252A)),
                Triple("Facebook", "https://www.facebook.com/share/1K9XwAjPjE/", Color(0xFF1877F2)),
                Triple("TikTok", "https://www.tiktok.com/@sobusvai00.2", Color(0xFF111111)),
                Triple("Telegram", "https://t.me/Mdsobusmiya99", Color(0xFF229ED9)))
            links.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { (n, u, c) ->
                        Button(onClick = { openUrl(ctx, u) }, Modifier.weight(1f).height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = c, contentColor = Color.White)) { Text(n) }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable fun Preview(st: AppState, clip: Clip?) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build().also { st.player = it } }
    DisposableEffect(Unit) { onDispose { st.player = null; player.release() } }
    LaunchedEffect(clip?.uri, clip?.startMs, clip?.endMs, clip?.filter, clip?.brightness, clip?.effect, clip?.transition, clip?.cropL, clip?.cropR, clip?.cropT, clip?.cropB, clip?.speed) {
        player.setVideoEffects(Exporter.previewEffects(clip))
        if (clip != null && !clip.isImage) {
            player.setMediaItem(MediaItem.Builder().setUri(clip.uri).setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder().setStartPositionMs(clip.startMs).setEndPositionMs(clip.endMs).build()).build())
            player.prepare()
        } else player.clearMediaItems()
    }
    LaunchedEffect(clip?.speed, clip?.volume) { player.playbackParameters = PlaybackParameters(clip?.speed ?: 1f); player.volume = clip?.volume ?: 1f }
    Box(Modifier.fillMaxWidth().height(230.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black), contentAlignment = Alignment.Center) {
        if (clip == null) Text("Add a video or photo to start")
        else if (clip.isImage) Text("Photo clip, ${fmt(clip.endMs - clip.startMs)}")
        else AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } },
            modifier = Modifier.fillMaxSize().graphicsLayer(rotationZ = clip.rotate.toFloat(), scaleX = if (clip.flip) -1f else 1f))
    }
}

@Composable fun Editor(st: AppState) {
    val ctx = LocalContext.current
    val p = st.project
    val clip = p.clips.getOrNull(st.sel)
    var tab by remember { mutableIntStateOf(0) }
    var text by remember { mutableStateOf("") }
    var tSize by remember { mutableFloatStateOf(32f) }
    var tY by remember { mutableFloatStateOf(0.7f) }
    var tColor by remember { mutableStateOf(0xFFFFC247.toInt()) }
    var tFont by remember { mutableStateOf("Default") }
    var ttsText by remember { mutableStateOf("") }
    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val ok = uris.mapNotNull { Media.probe(ctx, it) }
        if (ok.size < uris.size) st.message = "${uris.size - ok.size} file(s) could not be opened."
        if (ok.isNotEmpty()) { val first = st.project.clips.isEmpty(); st.project = st.project.copy(clips = st.project.clips + ok); if (first) st.sel = 0 }
    }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            st.project = st.project.copy(audio = st.project.audio + AudioTrack(uri.toString(), "Music"))
        }
    }
    val pickReplace = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val n = Media.probe(ctx, uri)
            if (n == null) st.message = "That file could not be opened."
            else st.updateClip { n.copy(speed = 1f) }
        }
    }
    val pickOverlay = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            st.project = st.project.copy(overlays = st.project.overlays + ImageOverlay(uri.toString(), 0.6f, 0.6f, 0.25f))
        }
    }
    val pickFont = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val d = java.io.File(ctx.filesDir, "fonts").also { it.mkdirs() }
                val f = java.io.File(d, "font_${System.currentTimeMillis()}.ttf")
                ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                android.graphics.Typeface.createFromFile(f)
                tFont = f.absolutePath; st.message = "Font loaded and selected."
            } catch (_: Exception) { st.message = "That is not a valid font file (.ttf or .otf)." }
        }
    }
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) st.startRec() else st.message = "Microphone permission was denied."
    }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { st.save(); st.screen = "home" }) { Text("Home") }
            Spacer(Modifier.weight(1f))
            OutlinedButton(onClick = { st.save(); st.message = "Project saved." }) { Text("Save") }
            Button(onClick = {
                if (p.clips.isEmpty()) st.message = "Add a video or photo first." else { st.player?.pause(); st.save(); st.screen = "export" }
            }) { Text("Export") }
        }
        Preview(st, clip)
        if (st.message.isNotEmpty()) Text(st.message, color = Amber)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(p.clips.size) { i ->
                val c = p.clips[i]
                FilterChip(selected = i == st.sel, onClick = { st.sel = i },
                    label = { Text("${i + 1}: ${if (c.isImage) "Photo" else fmt(c.endMs - c.startMs)}") })
            }
        }
        val names = listOf("Clips", "Trim", "Speed", "Canvas", "Text", "Filter", "Audio", "Crop", "Effects", "Overlay", "Templates")
        ScrollableTabRow(selectedTabIndex = tab, containerColor = Panel) { names.forEachIndexed { i, n -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(n) }) } }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (tab) {
                0 -> {
                    Button(onClick = { pickMedia.launch(arrayOf("video/*", "image/*")) }, Modifier.fillMaxWidth()) { Text("Add video or photo") }
                    if (clip != null) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                val pos = (st.player?.currentPosition ?: 0L) + clip.startMs
                                if (!clip.isImage && pos > clip.startMs + 200 && pos < clip.endMs - 200) {
                                    val l = p.clips.toMutableList(); l[st.sel] = clip.copy(endMs = pos); l.add(st.sel + 1, clip.copy(startMs = pos)); st.project = p.copy(clips = l)
                                } else st.message = "Pause the preview inside the clip, then tap Split."
                            }) { Text("Split here") }
                            OutlinedButton(onClick = { val l = p.clips.toMutableList(); l.add(st.sel + 1, clip); st.project = p.copy(clips = l) }) { Text("Duplicate") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                val l = p.clips.toMutableList(); l.removeAt(st.sel); st.project = p.copy(clips = l); st.sel = st.sel.coerceAtMost((l.size - 1).coerceAtLeast(0))
                            }) { Text("Delete") }
                            OutlinedButton(enabled = st.sel > 0, onClick = { val l = p.clips.toMutableList(); val c = l.removeAt(st.sel); l.add(st.sel - 1, c); st.project = p.copy(clips = l); st.sel-- }) { Text("Move left") }
                            OutlinedButton(enabled = st.sel < p.clips.size - 1, onClick = { val l = p.clips.toMutableList(); val c = l.removeAt(st.sel); l.add(st.sel + 1, c); st.project = p.copy(clips = l); st.sel++ }) { Text("Move right") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { pickReplace.launch(arrayOf("video/*", "image/*")) }) { Text("Replace") }
                            OutlinedButton(enabled = !clip.isImage, onClick = {
                                val pos = (st.player?.currentPosition ?: 0L) + clip.startMs
                                val bmp = Media.frameAt(ctx, clip.uri, pos)
                                if (bmp == null) st.message = "Could not read a frame here."
                                else {
                                    val f = java.io.File(ctx.filesDir, "freeze_${System.currentTimeMillis()}.jpg")
                                    f.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, it) }
                                    val img = Clip(Uri.fromFile(f).toString(), true, 2000, bmp.width, bmp.height)
                                    val l = p.clips.toMutableList()
                                    if (pos > clip.startMs + 200 && pos < clip.endMs - 200) { l[st.sel] = clip.copy(endMs = pos); l.add(st.sel + 1, img); l.add(st.sel + 2, clip.copy(startMs = pos)) }
                                    else l.add(st.sel + 1, img)
                                    st.project = p.copy(clips = l); st.message = "Freeze frame added (2 s)."
                                }
                            }) { Text("Freeze frame") }
                            OutlinedButton(enabled = !clip.isImage, onClick = {
                                val bmp = Media.frameAt(ctx, clip.uri, (st.player?.currentPosition ?: 0L) + clip.startMs)
                                st.message = if (bmp != null && Media.saveImage(ctx, bmp)) "Frame saved to Pictures/JiasminVideoStudio." else "Could not save the frame."
                            }) { Text("Capture") }
                        }
                        Text("Clips play in this order and are merged on export. Pause the preview where you want the freeze or capture.")
                    }
                }
                1 -> if (clip == null) Text("Add a clip first.") else if (clip.isImage) {
                    Text("Photo duration: ${fmt(clip.endMs)}")
                    Slider(value = clip.endMs / 1000f, onValueChange = { v -> val ms = (v * 1000).toLong(); st.updateClip { it.copy(durationMs = ms, endMs = ms) } }, valueRange = 1f..10f)
                } else {
                    Text("Start ${fmt(clip.startMs)}   End ${fmt(clip.endMs)}")
                    RangeSlider(value = clip.startMs.toFloat()..clip.endMs.toFloat(),
                        onValueChange = { r -> if (r.endInclusive - r.start >= 300f) st.updateClip { it.copy(startMs = r.start.toLong(), endMs = r.endInclusive.toLong()) } },
                        valueRange = 0f..clip.durationMs.toFloat())
                }
                2 -> if (clip == null || clip.isImage) Text("Select a video clip. Photos have no speed.") else {
                    Text("Speed ${clip.speed}x")
                    Slider(value = clip.speed, onValueChange = { v -> st.updateClip { it.copy(speed = Math.round(v * 4) / 4f) } }, valueRange = 0.25f..4f)
                }
                3 -> {
                    if (clip != null) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { st.updateClip { it.copy(rotate = (it.rotate + 90) % 360) } }) { Text("Rotate 90") }
                        OutlinedButton(onClick = { st.updateClip { it.copy(flip = !it.flip) } }) { Text("Flip") }
                    }
                    OutlinedButton(onClick = { st.project = p.copy(fill = !p.fill) }) { Text(if (p.fill) "Mode: Fill (crops the edges)" else "Mode: Fit (black bars)") }
                    Text("Aspect ratio")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(listOf("Original", "1:1", "4:5", "9:16", "16:9").size) { i ->
                            val a = listOf("Original", "1:1", "4:5", "9:16", "16:9")[i]
                            FilterChip(selected = p.aspect == a, onClick = { st.project = p.copy(aspect = a) }, label = { Text(a) })
                        }
                    }
                }
                4 -> {
                    OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Text (Bangla supported)") }, modifier = Modifier.fillMaxWidth())
                    Text("Size ${tSize.toInt()}"); Slider(value = tSize, onValueChange = { tSize = it }, valueRange = 12f..90f)
                    Text("Position: top to bottom"); Slider(value = tY, onValueChange = { tY = it }, valueRange = -0.9f..0.9f)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(FONTS.size) { i -> FilterChip(selected = tFont == FONTS[i], onClick = { tFont = FONTS[i] }, label = { Text(FONTS[i]) }) } }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0xFFFFC247.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF6B4A.toInt(), 0xFF35D6C4.toInt()).forEach { c ->
                            Box(Modifier.size(40.dp).clip(CircleShape).background(Color(c)).graphicsLayer(alpha = if (tColor == c) 1f else 0.5f)
                                .let { m -> m }, contentAlignment = Alignment.Center) { TextButton(onClick = { tColor = c }, Modifier.fillMaxSize()) { Text("") } }
                        }
                    }
                    OutlinedButton(onClick = { pickFont.launch(arrayOf("*/*")) }) { Text(if (tFont.startsWith("/")) "Custom font selected. Import another" else "Import font file (.ttf, .otf)") }
                    Button(onClick = {
                        if (text.isBlank()) st.message = "Type some text first."
                        else { st.project = p.copy(texts = p.texts + TextItem(text.trim(), -tY, tSize.toInt(), tColor, tFont)); text = "" }
                    }, Modifier.fillMaxWidth()) { Text("Add text") }
                    Text("Stickers")
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("😀", "😍", "🔥", "⭐", "❤️", "👍").forEach { e ->
                            OutlinedButton(onClick = { st.project = p.copy(texts = p.texts + TextItem(e, 0f, 80, 0xFFFFFFFF.toInt())) }, contentPadding = PaddingValues(6.dp)) { Text(e) }
                        }
                    }
                    p.texts.forEachIndexed { i, t ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(t.text, Modifier.weight(1f))
                            TextButton(onClick = { st.project = p.copy(texts = p.texts.filterIndexed { j, _ -> j != i }) }) { Text("Remove") }
                        }
                    }
                    Text("Text and stickers are drawn over the whole video on export.")
                }
                5 -> if (clip == null) Text("Add a clip first.") else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(6) { i ->
                            val f = listOf("None", "Warm", "Cool", "Mono", "Vivid", "Enhance")[i]
                            FilterChip(selected = clip.filter == f, onClick = { st.updateClip { it.copy(filter = f) } }, label = { Text(f) })
                        }
                    }
                    Text("Brightness ${(clip.brightness * 100).toInt()}")
                    Slider(value = clip.brightness, onValueChange = { v -> st.updateClip { it.copy(brightness = v) } }, valueRange = -0.5f..0.5f)
                    Text("Filters are applied on export. The preview shows the original colors.")
                }
                6 -> {
                    if (clip != null && !clip.isImage) {
                        Text("Clip volume ${(clip.volume * 100).toInt()}%")
                        Slider(value = clip.volume, onValueChange = { v -> st.updateClip { it.copy(volume = v) } }, valueRange = 0f..2f)
                        OutlinedButton(onClick = { st.updateClip { it.copy(volume = if (it.volume == 0f) 1f else 0f) } }) { Text(if (clip.volume == 0f) "Unmute clip" else "Mute clip") }
                        Text("Voice effect (changes pitch)")
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(VOICES.size) { i -> FilterChip(selected = clip.voice == VOICES[i], onClick = { st.updateClip { it.copy(voice = VOICES[i]) } }, label = { Text(VOICES[i]) }) } }
                    }
                    Button(onClick = { pickAudio.launch(arrayOf("audio/*")) }, Modifier.fillMaxWidth()) { Text("Add music") }
                    OutlinedButton(onClick = {
                        if (st.recording) st.stopRec()
                        else if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) st.startRec()
                        else mic.launch(android.Manifest.permission.RECORD_AUDIO)
                    }, Modifier.fillMaxWidth()) { Text(if (st.recording) "Stop recording" else "Record voice-over") }
                    p.audio.forEachIndexed { i, a ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${a.label} ${(a.volume * 100).toInt()}%", Modifier.width(120.dp))
                            Slider(value = a.volume, onValueChange = { v -> st.project = p.copy(audio = p.audio.mapIndexed { j, x -> if (j == i) x.copy(volume = v) else x }) }, valueRange = 0f..2f, modifier = Modifier.weight(1f))
                            TextButton(onClick = { st.project = p.copy(audio = p.audio.filterIndexed { j, _ -> j != i }) }) { Text("Remove") }
                        }
                    }
                    OutlinedTextField(value = ttsText, onValueChange = { ttsText = it }, label = { Text("Text to speech (device voice)") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { if (ttsText.isBlank()) st.message = "Type the words to speak first." else st.speak(ttsText.trim()) }, Modifier.fillMaxWidth()) { Text("Create speech") }
                    Text("Music and voice-over start at 0:00 and are cut to the video length.")
                }
                7 -> if (clip == null) Text("Add a clip first.") else {
                    Text("Crop each edge (removes the outer part of the picture)")
                    Text("Left ${(clip.cropL * 100).toInt()}%"); Slider(value = clip.cropL, onValueChange = { v -> st.updateClip { it.copy(cropL = v) } }, valueRange = 0f..0.45f)
                    Text("Right ${(clip.cropR * 100).toInt()}%"); Slider(value = clip.cropR, onValueChange = { v -> st.updateClip { it.copy(cropR = v) } }, valueRange = 0f..0.45f)
                    Text("Top ${(clip.cropT * 100).toInt()}%"); Slider(value = clip.cropT, onValueChange = { v -> st.updateClip { it.copy(cropT = v) } }, valueRange = 0f..0.45f)
                    Text("Bottom ${(clip.cropB * 100).toInt()}%"); Slider(value = clip.cropB, onValueChange = { v -> st.updateClip { it.copy(cropB = v) } }, valueRange = 0f..0.45f)
                    OutlinedButton(onClick = { st.updateClip { it.copy(cropL = 0f, cropR = 0f, cropT = 0f, cropB = 0f) } }) { Text("Reset crop") }
                }
                8 -> if (clip == null) Text("Add a clip first.") else {
                    Text("Effect")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(EFFECTS.size) { i -> FilterChip(selected = clip.effect == EFFECTS[i], onClick = { st.updateClip { it.copy(effect = EFFECTS[i]) } }, label = { Text(EFFECTS[i]) }) } }
                    Text("Transition at the start of this clip")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(TRANSITIONS.size) { i -> FilterChip(selected = clip.transition == TRANSITIONS[i], onClick = { st.updateClip { it.copy(transition = TRANSITIONS[i]) } }, label = { Text(TRANSITIONS[i]) }) } }
                    Text("Opacity ${(clip.opacity * 100).toInt()}% (blends the clip toward the black background)")
                    Slider(value = clip.opacity, onValueChange = { v -> st.updateClip { it.copy(opacity = v) } }, valueRange = 0.2f..1f)
                    Text("Fade comes up from black, Slide enters from the right, Zoom grows in. These play over the first half second of the clip. They are not cross-dissolves between two clips.")
                }
                9 -> {
                    Button(onClick = { pickOverlay.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth()) { Text("Add image overlay (logo, picture-in-picture photo)") }
                    p.overlays.forEachIndexed { i, o ->
                        fun upd(n: ImageOverlay) { st.project = p.copy(overlays = p.overlays.mapIndexed { j, x -> if (j == i) n else x }) }
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).padding(10.dp)) {
                            Text("Overlay ${i + 1}")
                            Text("Left to right"); Slider(value = o.x, onValueChange = { upd(o.copy(x = it)) }, valueRange = -0.9f..0.9f)
                            Text("Bottom to top"); Slider(value = o.y, onValueChange = { upd(o.copy(y = it)) }, valueRange = -0.9f..0.9f)
                            Text("Size ${(o.scale * 100).toInt()}% of width"); Slider(value = o.scale, onValueChange = { upd(o.copy(scale = it)) }, valueRange = 0.1f..0.8f)
                            TextButton(onClick = { st.project = p.copy(overlays = p.overlays.filterIndexed { j, _ -> j != i }) }) { Text("Remove") }
                        }
                    }
                    Text("Overlays are drawn over the whole video on export. Video picture-in-picture is not available.")
                }
                10 -> {
                    Text("A template sets aspect ratio, filter, effect and transition on every clip.")
                    val tpls = listOf(
                        listOf("Cinematic", "16:9", "Cool", "None", "Fade", "-0.05"),
                        listOf("Vlog", "9:16", "Enhance", "None", "Slide", "0"),
                        listOf("Retro", "1:1", "None", "Sepia", "Fade", "0"),
                        listOf("Story", "9:16", "Vivid", "Pulse", "Zoom", "0"))
                    tpls.forEach { t ->
                        OutlinedButton(onClick = {
                            st.project = p.copy(aspect = t[1], fill = true, clips = p.clips.map { c -> c.copy(filter = t[2], effect = t[3], transition = t[4], brightness = t[5].toFloat()) })
                            st.message = "${t[0]} template applied."
                        }, Modifier.fillMaxWidth()) { Text("${t[0]}  (${t[1]}, ${t[2]} filter, ${t[3]} effect, ${t[4]} transition)") }
                    }
                }
            }
        }
    }
}

@Composable fun ExportScreen(st: AppState) {
    val ctx = LocalContext.current
    val p = st.project
    val ratio = Dims.ratio(p)
    val sec = Dims.totalMs(p) / 1000.0
    var short by remember { mutableIntStateOf(1080) }
    var custom by remember { mutableStateOf("") }
    LaunchedEffect(st.exporting) { while (st.exporting) { st.pollProgress(); delay(300) } }
    val (w, h) = Dims.compute(ratio, short)
    val mime = Caps.best(w, h)
    val free = StatFs(ctx.cacheDir.absolutePath).availableBytes
    val size = Caps.fileBytes(w, h, sec)
    val enoughSpace = free > size * 1.3
    val best = Caps.highestSupported(ratio)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Export settings", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Coral)
        val presets = listOf("480p" to 480, "720p" to 720, "1080p" to 1080, "1440p" to 1440, "4K" to 2160, "8K" to 4320, "20K" to 11520)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(presets.size) { i ->
                val (n, s) = presets[i]
                FilterChip(selected = short == s, enabled = !st.exporting, onClick = { short = s; custom = "" }, label = { Text(n) })
            }
        }
        OutlinedTextField(value = custom, enabled = !st.exporting, onValueChange = { v ->
            custom = v.filter { it.isDigit() }.take(5); custom.toIntOrNull()?.let { if (it in 64..20000) short = it }
        }, label = { Text("Custom short side in pixels (64 to 20000)") }, modifier = Modifier.fillMaxWidth())
        if (custom.isNotEmpty() && (custom.toIntOrNull() ?: 0) !in 64..20000) Text("Enter a number from 64 to 20000.", color = Amber)
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).padding(12.dp)) {
            Text("Output: ${w} x $h" + (if (short >= 11520) "  (20K class)" else ""), fontWeight = FontWeight.SemiBold)
            Text("Codec: ${when (mime) { null -> "none available"; "video/hevc" -> "H.265"; else -> "H.264" }}")
            Text("Estimated file size: ${size / 1_000_000} MB (rough)")
            Text("Estimated memory: ${Caps.memoryBytes(w, h) / 1_000_000} MB")
            Text("Free temporary storage: ${free / 1_000_000} MB")
            Text("Estimated time: about ${(sec * (w.toLong() * h) / (1920.0 * 1080.0)).toInt().coerceAtLeast(1)} s (very rough)")
        }
        if (mime == null) {
            Text("This device has no video encoder that supports ${w} x $h. The file would not be valid, so export is disabled.", color = Amber)
            if (best != null) {
                val (bw, bh) = Dims.compute(ratio, best)
                OutlinedButton(onClick = { short = best; custom = "" }) { Text("Use highest supported: $bw x $bh") }
            }
        } else if (!enoughSpace) Text("Not enough free storage for this export. Free up space or pick a smaller size.", color = Amber)
        else if (w.toLong() * h > 8294400L * 4) Text("Very large output. It may fail or take a long time on this phone.", color = Amber)
        if (st.exporting) {
            LinearProgressIndicator(progress = { st.progress }, Modifier.fillMaxWidth())
            Text("Exporting ${(st.progress * 100).toInt()}%")
            OutlinedButton(onClick = { st.cancelExport() }) { Text("Cancel") }
        } else {
            Button(enabled = mime != null && enoughSpace, onClick = { st.startExport(w, h, mime!!) }, Modifier.fillMaxWidth().height(52.dp)) { Text("Start export") }
        }
        if (st.error.isNotEmpty()) Text(st.error, color = Amber)
        if (st.resultUri != null) {
            Text(st.resultInfo, color = Teal)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { try { ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(st.resultUri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { st.error = "No video player found." } }) { Text("Play") }
                OutlinedButton(onClick = { try { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, st.resultUri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { st.error = "Could not share." } }) { Text("Share") }
            }
        }
        TextButton(enabled = !st.exporting, onClick = { st.screen = "edit" }) { Text("Back to editor") }
    }
}
