@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package com.jiasmin.videostudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Typeface
import android.media.MediaCodecList
import android.net.Uri
import android.text.Spannable
import android.text.SpannableString
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.TypefaceSpan
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.Crop
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import com.google.common.collect.ImmutableList
import kotlin.math.sin

object Caps {
    private fun encoders(mime: String) = MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos
        .filter { it.isEncoder && it.supportedTypes.any { t -> t.equals(mime, true) } }

    fun supports(w: Int, h: Int, mime: String): Boolean = encoders(mime).any {
        try { it.getCapabilitiesForType(mime).videoCapabilities.isSizeSupported(w, h) } catch (_: Exception) { false }
    }

    /** Best encoder mime for this size, or null when no encoder on this device accepts it. */
    fun best(w: Int, h: Int): String? {
        val order = if (w.toLong() * h > 2_100_000L) listOf(MimeTypes.VIDEO_H265, MimeTypes.VIDEO_H264)
        else listOf(MimeTypes.VIDEO_H264, MimeTypes.VIDEO_H265)
        return order.firstOrNull { supports(w, h, it) }
    }

    val shortSides = listOf(11520, 4320, 2160, 1440, 1080, 720, 480)

    fun highestSupported(ratio: Double): Int? =
        shortSides.firstOrNull { s -> val (w, h) = Dims.compute(ratio, s); best(w, h) != null }

    fun bitrate(w: Int, h: Int): Long = (w.toLong() * h * 30 * 0.07).toLong().coerceIn(1_000_000L, 100_000_000L)
    fun fileBytes(w: Int, h: Int, sec: Double): Long = (bitrate(w, h) * sec / 8).toLong()
    fun memoryBytes(w: Int, h: Int): Long = w.toLong() * h * 4 * 8
}

object Exporter {
    private fun volumeProcessor(v: Float): AudioProcessor = ChannelMixingAudioProcessor().apply {
        for (ch in 1..2) putChannelMixingMatrix(ChannelMixingMatrix.create(ch, ch).scaleBy(v))
    }

    fun outMs(c: Clip): Long = if (c.isImage) c.endMs - c.startMs else ((c.endMs - c.startMs) / c.speed).toLong()

    private fun pitch(c: Clip) = when (c.voice) { "Chipmunk" -> 1.4f; "Deep" -> 0.75f; else -> 1f }

    private val sepia = floatArrayOf(0.393f, 0.349f, 0.272f, 0f, 0.769f, 0.686f, 0.534f, 0f, 0.189f, 0.168f, 0.131f, 0f, 0f, 0f, 0f, 1f)

    /** Time based effects and clip-start transitions. presentationTimeUs is relative to the clip. */
    private fun timed(c: Clip): List<Effect> {
        val dUs = (outMs(c) * 1000L).coerceAtLeast(1L).toFloat()
        val l = mutableListOf<Effect>()
        when (c.effect) {
            "Zoom in" -> l.add(MatrixTransformation { t ->
                val s = 1f + 0.25f * (t / dUs).coerceIn(0f, 1f); Matrix().apply { postScale(s, s) } })
            "Pulse" -> l.add(MatrixTransformation { t ->
                val s = 1f + 0.06f * sin(t / 1_000_000f * 9.42f); Matrix().apply { postScale(s, s) } })
            "Shake" -> l.add(MatrixTransformation { t ->
                Matrix().apply { postTranslate(0.02f * sin(t / 1_000_000f * 40f), 0.02f * sin(t / 1_000_000f * 53f)) } })
            "Invert" -> l.add(RgbFilter.createInvertedFilter())
            "Sepia" -> l.add(RgbMatrix { _, _ -> sepia })
        }
        val tr = 500_000f
        when (c.transition) {
            "Fade" -> l.add(RgbMatrix { t, _ ->
                val f = (t / tr).coerceIn(0f, 1f)
                floatArrayOf(f, 0f, 0f, 0f, 0f, f, 0f, 0f, 0f, 0f, f, 0f, 0f, 0f, 0f, 1f) })
            "Slide" -> l.add(MatrixTransformation { t ->
                val k = 1f - (t / tr).coerceIn(0f, 1f); Matrix().apply { postTranslate(2f * k * k, 0f) } })
            "Zoom" -> {
                l.add(MatrixTransformation { t ->
                    val s = 0.3f + 0.7f * (t / tr).coerceIn(0f, 1f); Matrix().apply { postScale(s, s) } })
                l.add(RgbMatrix { t, _ ->
                    val f = (t / tr).coerceIn(0f, 1f)
                    floatArrayOf(f, 0f, 0f, 0f, 0f, f, 0f, 0f, 0f, 0f, f, 0f, 0f, 0f, 0f, 1f) })
            }
        }
        return l
    }

    /** withTransform=false leaves rotate/flip out (the preview does those with graphicsLayer). */
    fun looks(c: Clip, withTransform: Boolean = true): List<Effect> {
        val l = mutableListOf<Effect>()
        if (c.cropL > 0f || c.cropR > 0f || c.cropT > 0f || c.cropB > 0f)
            l.add(Crop(-1f + 2 * c.cropL, 1f - 2 * c.cropR, -1f + 2 * c.cropB, 1f - 2 * c.cropT))
        if (withTransform && (c.rotate != 0 || c.flip)) l.add(ScaleAndRotateTransformation.Builder()
            .setRotationDegrees(c.rotate.toFloat()).setScale(if (c.flip) -1f else 1f, 1f).build())
        when (c.filter) {
            "Warm" -> l.add(RgbAdjustment.Builder().setRedScale(1.15f).setBlueScale(0.88f).build())
            "Cool" -> l.add(RgbAdjustment.Builder().setRedScale(0.88f).setBlueScale(1.15f).build())
            "Mono" -> l.add(RgbFilter.createGrayscaleFilter())
            "Vivid" -> l.add(HslAdjustment.Builder().adjustSaturation(35f).build())
            "Enhance" -> { l.add(Contrast(0.15f)); l.add(HslAdjustment.Builder().adjustSaturation(20f).build()) }
        }
        if (c.brightness != 0f) l.add(Brightness(c.brightness))
        if (c.opacity < 1f) { val o = c.opacity; l.add(RgbMatrix { _, _ -> floatArrayOf(o, 0f, 0f, 0f, 0f, o, 0f, 0f, 0f, 0f, o, 0f, 0f, 0f, 0f, 1f) }) }
        l.addAll(timed(c))
        return l
    }

    fun previewEffects(c: Clip?): List<Effect> = if (c == null || c.isImage) emptyList() else looks(c, false)

    fun composition(ctx: Context, p: Project, w: Int, h: Int): Composition {
        val items = p.clips.map { c ->
            if (c.isImage) {
                val ms = c.endMs - c.startMs
                EditedMediaItem.Builder(MediaItem.Builder().setUri(c.uri).setImageDurationMs(ms).build())
                    .setDurationUs(ms * 1000).setFrameRate(30).setEffects(Effects(emptyList(), looks(c))).build()
            } else {
                val clipping = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.startMs).setEndPositionMs(c.endMs).build()
                val audioFx = mutableListOf<AudioProcessor>()
                val videoFx = mutableListOf<Effect>()
                val pt = pitch(c)
                if (c.speed != 1f || pt != 1f) audioFx.add(SonicAudioProcessor().apply { setSpeed(c.speed); setPitch(pt) })
                if (c.speed != 1f) videoFx.add(SpeedChangeEffect(c.speed))
                if (c.volume != 1f) audioFx.add(volumeProcessor(c.volume))
                videoFx.addAll(looks(c))
                EditedMediaItem.Builder(MediaItem.Builder().setUri(c.uri).setClippingConfiguration(clipping).build())
                    .setEffects(Effects(audioFx, videoFx)).build()
            }
        }
        val total = Dims.totalMs(p)
        val seqs = mutableListOf(EditedMediaItemSequence(items))
        p.audio.forEach { a ->
            val clipping = MediaItem.ClippingConfiguration.Builder().setEndPositionMs(total).build()
            val item = EditedMediaItem.Builder(MediaItem.Builder().setUri(a.uri).setClippingConfiguration(clipping).build())
                .setRemoveVideo(true)
                .setEffects(Effects(if (a.volume != 1f) listOf(volumeProcessor(a.volume)) else emptyList(), emptyList()))
                .build()
            seqs.add(EditedMediaItemSequence(listOf(item)))
        }
        val fx = mutableListOf<Effect>(Presentation.createForWidthAndHeight(w, h, if (p.fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT))
        val b = ImmutableList.builder<TextureOverlay>()
        var n = 0
        p.texts.forEach { t ->
            val s = SpannableString(t.text)
            s.setSpan(ForegroundColorSpan(t.color), 0, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            s.setSpan(AbsoluteSizeSpan((t.sizePx * minOf(w, h) / 360f).toInt().coerceAtLeast(12)), 0, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            val tf: Typeface = if (t.font.startsWith("/")) {
                try { Typeface.createFromFile(t.font) } catch (_: Exception) { Typeface.DEFAULT_BOLD }
            } else {
                val face = when (t.font) { "Serif" -> Typeface.SERIF; "Mono" -> Typeface.MONOSPACE; else -> Typeface.SANS_SERIF }
                Typeface.create(face, Typeface.BOLD)
            }
            s.setSpan(TypefaceSpan(tf), 0, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            b.add(TextOverlay.createStaticTextOverlay(s, OverlaySettings.Builder().setBackgroundFrameAnchor(0f, t.y).build())); n++
        }
        p.overlays.forEach { o ->
            try {
                val bmp = ctx.contentResolver.openInputStream(Uri.parse(o.uri))?.use { BitmapFactory.decodeStream(it) }
                if (bmp != null && bmp.width > 0) {
                    val tw = (w * o.scale).toInt().coerceAtLeast(16)
                    val th = (tw.toLong() * bmp.height / bmp.width).toInt().coerceAtLeast(16)
                    val sc = Bitmap.createScaledBitmap(bmp, tw, th, true)
                    b.add(BitmapOverlay.createStaticBitmapOverlay(sc, OverlaySettings.Builder().setBackgroundFrameAnchor(o.x, o.y).build())); n++
                }
            } catch (_: Exception) {}
        }
        if (n > 0) fx.add(OverlayEffect(b.build()))
        return Composition.Builder(seqs).setEffects(Effects(emptyList(), fx)).build()
    }
}
