@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package com.jiasmin.videostudio

import android.content.Context
import android.media.MediaRecorder
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File
import kotlin.concurrent.thread

class AppState(val ctx: Context) {
    var screen by mutableStateOf("home")
    var project by mutableStateOf(Project("Project"))
    var sel by mutableIntStateOf(0)
    var message by mutableStateOf("")
    var player: ExoPlayer? = null

    var exporting by mutableStateOf(false)
    var progress by mutableFloatStateOf(0f)
    var resultUri by mutableStateOf<Uri?>(null)
    var resultInfo by mutableStateOf("")
    var error by mutableStateOf("")
    private var transformer: Transformer? = null
    private val main = Handler(Looper.getMainLooper())

    var recorder: MediaRecorder? = null
    private var recFile: File? = null
    var recording by mutableStateOf(false)

    fun save() { try { Store.save(ctx, project) } catch (e: Exception) { message = "Could not save project: ${e.message}" } }

    fun updateClip(f: (Clip) -> Clip) {
        val l = project.clips.toMutableList()
        if (sel !in l.indices) return
        l[sel] = f(l[sel]); project = project.copy(clips = l)
    }

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    fun startRec() {
        try {
            val f = File(ctx.filesDir, "voice_${System.currentTimeMillis()}.m4a")
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(f.absolutePath)
            r.prepare(); r.start()
            recorder = r; recFile = f; recording = true
        } catch (e: Exception) { message = "Recording failed: ${e.message}"; releaseRecorder() }
    }

    fun stopRec() {
        val r = recorder ?: return
        var ok = true
        try { r.stop() } catch (_: Exception) { ok = false }
        releaseRecorder()
        val f = recFile
        if (ok && f != null) project = project.copy(audio = project.audio + AudioTrack(Uri.fromFile(f).toString(), "Voice-over"))
        else message = "Recording was too short."
    }

    fun speak(text: String) {
        val f = File(ctx.filesDir, "tts_${System.currentTimeMillis()}.wav")
        val holder = arrayOfNulls<TextToSpeech>(1)
        message = "Preparing speech..."
        holder[0] = TextToSpeech(ctx) { status ->
            val e = holder[0]
            if (status != TextToSpeech.SUCCESS || e == null) {
                message = "No text-to-speech engine is available on this phone."; e?.shutdown()
            } else {
                val bn = Locale("bn", "BD")
                e.setLanguage(if (e.isLanguageAvailable(bn) >= TextToSpeech.LANG_AVAILABLE) bn else Locale.getDefault())
                e.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        main.post { project = project.copy(audio = project.audio + AudioTrack(Uri.fromFile(f).toString(), "Speech")); message = "Speech added in the Audio tab."; e.shutdown() }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post { message = "Speech could not be created."; e.shutdown() } }
                })
                e.synthesizeToFile(text, Bundle(), f, "jvs")
            }
        }
    }

    fun releaseRecorder() { try { recorder?.release() } catch (_: Exception) {}; recorder = null; recording = false }

    fun startExport(w: Int, h: Int, mime: String) {
        error = ""; resultUri = null; resultInfo = ""; progress = 0f
        val out = File(ctx.cacheDir, "export.mp4"); out.delete()
        try {
            val t = Transformer.Builder(ctx).setVideoMimeType(mime).setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        thread {
                            val uri = Media.saveToGallery(ctx, out)
                            val dims = Media.dims(ctx, uri)
                            main.post {
                                exporting = false
                                if (uri != null) { resultUri = uri; resultInfo = "Saved to Movies/JiasminVideoStudio. Output size: $dims (requested ${w}x$h)." }
                                else error = "Export finished but saving to the gallery failed."
                            }
                        }
                    }
                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        exporting = false
                        error = "Export failed (${exportException.errorCodeName}): ${exportException.message}. Try a smaller size."
                    }
                }).build()
            transformer = t; exporting = true
            t.start(Exporter.composition(ctx, project, w, h), out.absolutePath)
        } catch (e: Exception) { exporting = false; error = "Could not start export: ${e.message}" }
    }

    fun cancelExport() { transformer?.cancel(); exporting = false; error = "Export cancelled." }

    fun pollProgress() {
        val t = transformer ?: return
        val h = ProgressHolder()
        if (t.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) progress = h.progress / 100f
    }
}
